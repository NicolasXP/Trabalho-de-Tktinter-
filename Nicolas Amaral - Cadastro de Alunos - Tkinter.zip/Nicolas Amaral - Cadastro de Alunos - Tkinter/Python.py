import sqlite3

# Conectar ao banco (ou criar se não existir)
conexao = sqlite3.connect('escola.db')  # Use o mesmo nome que você criou no DB Browser
cursor = conexao.cursor()

# Criar tabela (se ainda não existir)
cursor.execute('''
CREATE TABLE IF NOT EXISTS alunos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    idade INTEGER,
    curso TEXT
)
''')

# Função para inserir dados
def inserir_aluno(nome, idade, curso):
    cursor.execute("INSERT INTO alunos (nome, idade, curso) VALUES (?, ?, ?)", (nome, idade, curso))
    conexao.commit()

# Função para listar os alunos
def listar_alunos():
    cursor.execute("SELECT * FROM alunos")
    for aluno in cursor.fetchall():
        print(aluno)

# Função para atualizar um aluno
def atualizar_aluno(id, nome, idade, curso):
    cursor.execute("UPDATE alunos SET nome=?, idade=?, curso=? WHERE id=?", (nome, idade, curso, id))
    conexao.commit()

# Função para deletar um aluno
def deletar_aluno(id):
    cursor.execute("DELETE FROM alunos WHERE id=?", (id,))
    conexao.commit()

# ---- Testes ----
print("Inserindo aluno...")
inserir_aluno("Maria", 22, "Engenharia")
inserir_aluno("João", 25, "Medicina")

print("Lista de alunos:")
listar_alunos()

print("Atualizando aluno ID 1...")
atualizar_aluno(1, "Maria Eduarda", 23, "Engenharia de Software")

print("Lista após atualização:")
listar_alunos()

print("Removendo aluno ID 2...")
deletar_aluno(2)

print("Lista final:")
listar_alunos()

# Fechar conexão
conexao.close()
