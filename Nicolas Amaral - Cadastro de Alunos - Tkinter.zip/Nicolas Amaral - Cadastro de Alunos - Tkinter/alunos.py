import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Variável global para armazenar a matrícula selecionada
matricula_selecionada = None


# ================================
# Banco de Dados
# ================================
def conectar():
    return sqlite3.connect("escola.db")


def criar_tabela():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS alunos (
            matricula TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            idade INTEGER,
            curso TEXT
        )
    """)

    conexao.commit()
    conexao.close()


# ================================
# Funções do CRUD
# ================================
def inserir_aluno():
    matricula = entry_matricula.get()
    nome = entry_nome.get()
    idade = entry_idade.get()
    curso = entry_curso.get()

    if matricula and nome and idade and curso:
        try:
            conexao = conectar()
            cursor = conexao.cursor()

            cursor.execute(
                "INSERT INTO alunos (matricula, nome, idade, curso) VALUES (?, ?, ?, ?)",
                (matricula, nome, idade, curso)
            )

            conexao.commit()
            conexao.close()

            messagebox.showinfo("Sucesso", "Aluno inserido com sucesso!")
            limpar_campos()
            listar_alunos()

        except sqlite3.IntegrityError:
            messagebox.showerror("Erro", "Matrícula já existe!")
        except Exception as e:
            messagebox.showerror("Erro", str(e))
    else:
        messagebox.showwarning("Aviso", "Preencha todos os campos.")


def listar_alunos():
    for row in tree.get_children():
        tree.delete(row)

    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute("SELECT * FROM alunos")
    alunos = cursor.fetchall()
    conexao.close()

    for aluno in alunos:
        tree.insert("", "end", values=aluno)


def atualizar_aluno():
    global matricula_selecionada

    if matricula_selecionada is None:
        messagebox.showwarning("Aviso", "Selecione um aluno para atualizar.")
        return

    nova_matricula = entry_matricula.get()
    nome = entry_nome.get()
    idade = entry_idade.get()
    curso = entry_curso.get()

    if nova_matricula and nome and idade and curso:
        try:
            conexao = conectar()
            cursor = conexao.cursor()

            cursor.execute(
                "UPDATE alunos SET matricula = ?, nome = ?, idade = ?, curso = ? WHERE matricula = ?",
                (nova_matricula, nome, idade, curso, matricula_selecionada)
            )

            conexao.commit()
            conexao.close()

            messagebox.showinfo("Sucesso", "Aluno atualizado com sucesso!")

            limpar_campos()
            listar_alunos()

            matricula_selecionada = None

        except sqlite3.IntegrityError:
            messagebox.showerror("Erro", "A nova matrícula já existe!")
        except Exception as e:
            messagebox.showerror("Erro", str(e))
    else:
        messagebox.showwarning("Aviso", "Preencha todos os campos.")


def remover_aluno():
    global matricula_selecionada

    selecionado = tree.selection()
    if selecionado:
        item = tree.item(selecionado)
        aluno = item["values"]
        matricula = aluno[0]

        resposta = messagebox.askyesno(
            "Confirmação", f"Deseja remover o aluno {aluno[1]}?"
        )
        if resposta:
            conexao = conectar()
            cursor = conexao.cursor()

            cursor.execute("DELETE FROM alunos WHERE matricula = ?", (matricula,))

            conexao.commit()
            conexao.close()

            messagebox.showinfo("Sucesso", "Aluno removido com sucesso!")
            listar_alunos()
            limpar_campos()

            matricula_selecionada = None

    else:
        messagebox.showwarning("Aviso", "Selecione um aluno para remover.")


def limpar_campos():
    global matricula_selecionada

    entry_matricula.delete(0, tk.END)
    entry_nome.delete(0, tk.END)
    entry_idade.delete(0, tk.END)
    entry_curso.delete(0, tk.END)

    matricula_selecionada = None


def selecionar_aluno(event):
    global matricula_selecionada

    selecionado = tree.selection()
    if selecionado:
        item = tree.item(selecionado)
        aluno = item["values"]
        matricula_selecionada = aluno[0]

        entry_matricula.delete(0, tk.END)
        entry_matricula.insert(0, aluno[0])

        entry_nome.delete(0, tk.END)
        entry_nome.insert(0, aluno[1])

        entry_idade.delete(0, tk.END)
        entry_idade.insert(0, aluno[2])

        entry_curso.delete(0, tk.END)
        entry_curso.insert(0, aluno[3])


# ================================
# Interface Gráfica (Tkinter)
# ================================

root = tk.Tk()
root.title("Cadastro de Alunos")
root.geometry("750x550")
root.config(bg="#e6f2ff")

criar_tabela()

# Frame dos campos de entrada
frame = tk.Frame(root, bg="#f2f2f2", bd=2, relief="solid")
frame.place(relx=0.5, rely=0.08, anchor="n", width=700, height=180)

# Labels e entradas
tk.Label(frame, text="Matrícula:", bg="#f2f2f2", font=("Arial", 10)).grid(
    row=0, column=0, padx=10, pady=10, sticky="e"
)
entry_matricula = tk.Entry(frame, font=("Arial", 12), width=25)
entry_matricula.grid(row=0, column=1, padx=10, pady=10)

tk.Label(frame, text="Nome:", bg="#f2f2f2", font=("Arial", 10)).grid(
    row=1, column=0, padx=10, pady=10, sticky="e"
)
entry_nome = tk.Entry(frame, font=("Arial", 12), width=25)
entry_nome.grid(row=1, column=1, padx=10, pady=10)

tk.Label(frame, text="Idade:", bg="#f2f2f2", font=("Arial", 10)).grid(
    row=0, column=2, padx=10, pady=10, sticky="e"
)
entry_idade = tk.Entry(frame, font=("Arial", 12), width=25)
entry_idade.grid(row=0, column=3, padx=10, pady=10)

tk.Label(frame, text="Curso:", bg="#f2f2f2", font=("Arial", 10)).grid(
    row=1, column=2, padx=10, pady=10, sticky="e"
)
entry_curso = tk.Entry(frame, font=("Arial", 12), width=25)
entry_curso.grid(row=1, column=3, padx=10, pady=10)


# Frame dos botões
btn_frame = tk.Frame(root, bg="#e6f2ff")
btn_frame.place(relx=0.5, rely=0.4, anchor="n")

btn_inserir = tk.Button(
    btn_frame, text="Inserir", command=inserir_aluno, bg="#4CAF50", fg="white", width=15, font=("Arial", 11, "bold")
)
btn_inserir.grid(row=0, column=0, padx=10, pady=10)

btn_listar = tk.Button(
    btn_frame, text="Listar", command=listar_alunos, bg="#2196F3", fg="white", width=15, font=("Arial", 11, "bold")
)
btn_listar.grid(row=0, column=1, padx=10, pady=10)

btn_atualizar = tk.Button(
    btn_frame, text="Atualizar", command=atualizar_aluno, bg="#FFC107", fg="white", width=15, font=("Arial", 11, "bold")
)
btn_atualizar.grid(row=0, column=2, padx=10, pady=10)

btn_remover = tk.Button(
    btn_frame, text="Remover", command=remover_aluno, bg="#F44336", fg="white", width=15, font=("Arial", 11, "bold")
)
btn_remover.grid(row=0, column=3, padx=10, pady=10)


# Treeview para exibir alunos
columns = ("Matrícula", "Nome", "Idade", "Curso")
tree = ttk.Treeview(root, columns=columns, show="headings", height=12)

for col in columns:
    tree.heading(col, text=col)
    tree.column(col, anchor="center", width=160)

tree.place(relx=0.5, rely=0.55, anchor="n", width=700, height=250)

tree.bind("<<TreeviewSelect>>", selecionar_aluno)


# Inicia a interface gráfica
root.mainloop()
