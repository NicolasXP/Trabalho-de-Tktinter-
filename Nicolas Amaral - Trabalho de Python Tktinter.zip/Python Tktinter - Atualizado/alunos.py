import sqlite3
import tkinter as tk
from tkinter import messagebox, ttk

# Função para conectar ao banco
def conectar():
    try:
        conn = sqlite3.connect("escola.db")
        print("Conectado ao banco de dados.")
        return conn
    except sqlite3.Error as e:
        print(f"Erro de conexão: {e}")
        return None

# Função para criar a tabela, caso não exista
def criar_tabela():
    conexao = conectar()
    if conexao:
        try:
            cursor = conexao.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS alunos (
                matricula TEXT PRIMARY KEY,
                nome TEXT NOT NULL,
                idade INTEGER,
                curso TEXT
            )
            """)
            conexao.commit()
            print("Tabela criada ou já existe.")
        except sqlite3.Error as e:
            print(f"Erro ao criar a tabela: {e}")
        finally:
            conexao.close()

# Função para inserir aluno
def inserir_aluno():
    matricula = entry_matricula.get()
    nome = entry_nome.get()
    idade = entry_idade.get()
    curso = entry_curso.get()

    if matricula and nome and idade and curso:
        try:
            conexao = conectar()
            if conexao:
                cursor = conexao.cursor()
                cursor.execute("INSERT INTO alunos (matricula, nome, idade, curso) VALUES (?, ?, ?, ?)", 
                               (matricula, nome, idade, curso))
                conexao.commit()
                print(f"Aluno {nome} inserido com sucesso!")  # Debug: confirma a inserção
                conexao.close()
                messagebox.showinfo("Sucesso", "Aluno inserido com sucesso!")
                limpar_campos()
                listar_alunos()  # Atualiza a tabela após inserção
        except sqlite3.IntegrityError:
            messagebox.showerror("Erro", "A matrícula já existe!")
            print("Erro de integridade: matrícula já existente.")
        except sqlite3.Error as e:
            messagebox.showerror("Erro", f"Ocorreu um erro: {e}")
            print(f"Erro ao inserir o aluno: {e}")
    else:
        messagebox.showwarning("Aviso", "Por favor, preencha todos os campos.")

# Função para listar alunos no Treeview
def listar_alunos():
    for row in tree.get_children():  # Limpa a lista existente
        tree.delete(row)

    conexao = conectar()
    if conexao:
        try:
            cursor = conexao.cursor()
            cursor.execute("SELECT * FROM alunos")
            alunos = cursor.fetchall()
            conexao.close()

            if alunos:
                for aluno in alunos:
                    tree.insert("", "end", values=aluno)
            else:
                messagebox.showinfo("Aviso", "Nenhum aluno cadastrado.")
                print("Nenhum aluno encontrado.")
        except sqlite3.Error as e:
            print(f"Erro ao listar alunos: {e}")

# Função para atualizar aluno
def atualizar_aluno():
    matricula = entry_matricula.get()
    nome = entry_nome.get()
    idade = entry_idade.get()
    curso = entry_curso.get()

    if matricula and nome and idade and curso:
        try:
            conexao = conectar()
            if conexao:
                cursor = conexao.cursor()
                cursor.execute("UPDATE alunos SET nome = ?, idade = ?, curso = ? WHERE matricula = ?", 
                               (nome, idade, curso, matricula))
                conexao.commit()
                print(f"Aluno {nome} atualizado com sucesso!")  # Debug: confirma a atualização
                conexao.close()
                messagebox.showinfo("Sucesso", "Aluno atualizado com sucesso!")
                limpar_campos()
                listar_alunos()  # Atualiza a tabela após atualização
        except sqlite3.Error as e:
            messagebox.showerror("Erro", f"Ocorreu um erro: {e}")
            print(f"Erro ao atualizar o aluno: {e}")
    else:
        messagebox.showwarning("Aviso", "Por favor, preencha todos os campos.")

# Função para remover aluno selecionado
def remover_aluno():
    # Obtém o item selecionado na tabela
    selected_item = tree.selection()
    if selected_item:
        # Obtém os dados do aluno selecionado
        aluno = tree.item(selected_item, "values")
        matricula = aluno[0]

        # Confirmação para remoção
        resposta = messagebox.askyesno("Confirmar", f"Tem certeza que deseja remover o aluno {aluno[1]}?")
        if resposta:
            conexao = conectar()
            if conexao:
                cursor = conexao.cursor()
                cursor.execute("DELETE FROM alunos WHERE matricula = ?", (matricula,))
                conexao.commit()
                print(f"Aluno {aluno[1]} removido com sucesso!")  # Debug: confirma a remoção
                conexao.close()
                messagebox.showinfo("Sucesso", "Aluno removido com sucesso!")
                listar_alunos()  # Atualiza a tabela após remoção
    else:
        messagebox.showwarning("Aviso", "Por favor, selecione um aluno para remover.")

# Função para limpar os campos
def limpar_campos():
    entry_matricula.delete(0, tk.END)
    entry_nome.delete(0, tk.END)
    entry_idade.delete(0, tk.END)
    entry_curso.delete(0, tk.END)

# Configuração da janela principal
root = tk.Tk()
root.title("Sistema de Cadastro de Alunos")
root.geometry("700x500")
root.config(bg="#f0f0f0")

# Criar tabela no banco de dados se não existir
criar_tabela()

# Labels e campos de entrada
tk.Label(root, text="Matrícula:", bg="#f0f0f0", font=("Arial", 10)).grid(row=0, column=0, padx=10, pady=5, sticky="e")
entry_matricula = tk.Entry(root, font=("Arial", 12), bd=2, relief="solid", highlightthickness=2, highlightbackground="#4CAF50")
entry_matricula.grid(row=0, column=1, padx=10, pady=5)

tk.Label(root, text="Nome:", bg="#f0f0f0", font=("Arial", 10)).grid(row=1, column=0, padx=10, pady=5, sticky="e")
entry_nome = tk.Entry(root, font=("Arial", 12), bd=2, relief="solid", highlightthickness=2, highlightbackground="#4CAF50")
entry_nome.grid(row=1, column=1, padx=10, pady=5)

tk.Label(root, text="Idade:", bg="#f0f0f0", font=("Arial", 10)).grid(row=2, column=0, padx=10, pady=5, sticky="e")
entry_idade = tk.Entry(root, font=("Arial", 12), bd=2, relief="solid", highlightthickness=2, highlightbackground="#4CAF50")
entry_idade.grid(row=2, column=1, padx=10, pady=5)

tk.Label(root, text="Curso:", bg="#f0f0f0", font=("Arial", 10)).grid(row=3, column=0, padx=10, pady=5, sticky="e")
entry_curso = tk.Entry(root, font=("Arial", 12), bd=2, relief="solid", highlightthickness=2, highlightbackground="#4CAF50")
entry_curso.grid(row=3, column=1, padx=10, pady=5)

# Botões com estética melhorada
btn_inserir = tk.Button(root, text="Inserir Aluno", command=inserir_aluno, bg="#4CAF50", fg="white", font=("Arial", 12), relief="flat", bd=4, highlightthickness=2, highlightbackground="#4CAF50", activebackground="#45a049")
btn_inserir.grid(row=4, column=0, padx=10, pady=20)

btn_listar = tk.Button(root, text="Listar Alunos", command=listar_alunos, bg="#2196F3", fg="white", font=("Arial", 12), relief="flat", bd=4, highlightthickness=2, highlightbackground="#2196F3", activebackground="#1e88e5")
btn_listar.grid(row=4, column=1, padx=10, pady=20)

btn_atualizar = tk.Button(root, text="Atualizar Aluno", command=atualizar_aluno, bg="#FFC107", fg="white", font=("Arial", 12), relief="flat", bd=4, highlightthickness=2, highlightbackground="#FFC107", activebackground="#FFB300")
btn_atualizar.grid(row=5, column=0, padx=10, pady=20)

btn_remover = tk.Button(root, text="Remover Aluno", command=remover_aluno, bg="#F44336", fg="white", font=("Arial", 12), relief="flat", bd=4, highlightthickness=2, highlightbackground="#F44336", activebackground="#E53935")
btn_remover.grid(row=5, column=1, padx=10, pady=20)

# Treeview para exibir os alunos como uma tabela
columns = ("Matrícula", "Nome", "Idade", "Curso")
tree = ttk.Treeview(root, columns=columns, show="headings", height=10)

tree.heading("Matrícula", text="Matrícula")
tree.heading("Nome", text="Nome")
tree.heading("Idade", text="Idade")
tree.heading("Curso", text="Curso")

# Definir a largura das colunas
tree.column("Matrícula", width=100, anchor="center")
tree.column("Nome", width=200, anchor="w")
tree.column("Idade", width=100, anchor="center")
tree.column("Curso", width=150, anchor="w")

tree.grid(row=6, column=0, columnspan=2, padx=10, pady=20)

# Iniciar a interface gráfica
root.mainloop()

